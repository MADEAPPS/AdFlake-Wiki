
AdFlake Android Client SDK
==========================
 
 * Please see http://www.adflake.com/sdk for setup instructions, 
   the latest news, releases and issue reports.
   
 * A detailed integration guide is available at http://www.adflake.com/sdk

 * AdFlake-SampleApp provides a sample that shows how implement the AdFlake SDK progamatically as well as with a layout XML.
   To use the sample app, import the project into your eclipse workspace (File->Import...) without copying files.
   Copy the ad network jar files you want to test into the lib/ folder. 
   Due to licensing issues we're not able to include ad network jars at this time, but we're working on resolving this issue.
 
 * Changelog.txt for changes in this version

 * Also check out our blog at http://www.made-apps.com for the latest news!