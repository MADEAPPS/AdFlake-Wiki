
AdFlake iOS Client SDK
======================
 
 * Please see http://www.adflake.com/sdk for setup instructions, 
   the latest news, releases and issue reports.
   
 * A detailed integration guide is available at http://www.adflake.com/sdk

 * AdFlake-SampleApp provides a sample that tries to load/link all network libs that are supported by AdFlake.
 
 * AdFlake-SampleApp-Minimal provides a sample that only links iAD for fast testing of AdFlake.
 
 * Changelog.txt for changes in this version

 * Also check out our blog at http://www.made-apps.com for the latest news!