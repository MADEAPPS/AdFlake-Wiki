//
//  AdFlakeAdapterTodacell.h
//  AdFlakeSDK-Sample
//
//  Created by dutty on 04.10.13.
//
//

#import "AdFlakeAdNetworkAdapter.h"

@interface AdFlakeAdapterTodacell : AdFlakeAdNetworkAdapter
{
	UIView *_view;
}
@end
